import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {

    public static void main(String[] args) {
//        notification();
        news();
    }

    public static void notification()  {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();

        driver.get("https://facebook.com");

        WebElement emailbox = driver.findElement(By.id("email"));
        WebElement passbox = driver.findElement(By.id("pass"));
        WebElement btn = driver.findElement(By.id("u_0_2"));

        emailbox.sendKeys("tungat72@ovi.com");
        passbox.sendKeys("600383");
        btn.click();

        WebElement notif = driver.findElement(By.id("notificationsCountValue"));
        System.out.println("You got " + notif.getText()+ " notifications");

        try {
            Thread.sleep(500000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }


        driver.close();
    }

    public static void news() {
        System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
        WebDriver driver = new ChromeDriver();

//        driver.get("http://www.ethiopianreporter.com/");


        String expectedUrl = "https://www.bbc.com/";
        driver.get(expectedUrl);
        try{
            Assert.assertEquals(expectedUrl, driver.getCurrentUrl());
            System.out.println("Navigated to correct webpage");

            WebElement content = driver.findElement(By.className("module--regional-news"));

            System.out.println(content.getText());
            System.out.println(content.getCssValue("module--regional-news"));
        }
        catch(Throwable pageNavigationError){
            System.out.println("Didn't navigate to correct webpage");
        }
    }
}
